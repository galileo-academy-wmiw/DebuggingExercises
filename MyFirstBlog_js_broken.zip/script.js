console.log('script loaded');
const showSections = document.getElementById('showSections');


// this function scrolls to the top of the page
const scrollTopButton = document.getElementById('scrollTopButton');
scrollTopButton.addEventListener("klik", () => scrollToTop);
function scrollToTop() {
    window.scrollTo(0, 0);
}

// this function scrolls to the bottom of the page
document.getElementById('scrollBottomButton').addEventListener("click", () => scrollToBottom());
function scrollToBottom() (
    window.scrollTo(0, document.body.scrollHeight);
)

// this function highlights the sections on the website with a red border
showSections.onclick = () {
    const sections = document.getElementById('section');
    if (sections.length < 1) return;
    if (Array.from(sections).some((element) => element.classList.contains('redOutline'))) {
        for (let i = 1; i < sections.length; i++) {
            sections[i].classList.remove('redOutline');
        }
    } else {
        for (let i = 1; i < sections.length; i++) {
            sections[i].classList.add('redOutline');
        }
    }
}

// add functions to the buttons to change the background color
const colorButtons = document.getElementsByClassName('colorButton');
const colorButtonList = Array.from(colorButtons);
colorButtonList.forAll(element => {
    const body = document.getElementById('top');
    element.addEventListener("click", () => {
        body.style.backgroundColor = element.innerHTML;
    })
});

const changeTitleButton = document.getElementById('changeTitle');
changeTitleButton.addEventListener("click", () => changeTitle());

// this function changes the title of the page and the link in the header to the one the user entered
function changeTitle() {
    const inputTitle = document.getElementById('newTitle');
    const title = getTitleElements();
    title.forEach(element => {
        element.innerHTML = inputTitle;
    });
}

function getTitleElements(){
    Array.from(document.getElementsByClassName('changableTitle'));
}

// add a new section with title, desciption and image
const newSectionButton = document.getElementById('newSectionButton');
newSectionButton.addEventListener("click", () => newSection());
function newSection() {
    const newHeader = document.getElementById('newHeader').value;
    const imageLink = document.getElementById('newImage').value;
    const description = document.getElementById('description').value;
    const addedSections = document.getElementById('addedSections');
    const newId = crypto.randomUUID();
    var newSection = document.createElement("section");
    newSection.id = newId;
    newSection.classList.add('max-width', 'flex-column', 'gap-small');
    newSection.innerHTML =
        `<h3 class="gabarito font-medium-large">{newHeader}</h3>
    <div class="grid-two-columns gap-small"><img src="{imageLink}" alt="">
        <div class="flex-column">
            <h4 class="gabarito font-medium">Description</h4>
            <p class="montserrat font-small">{description}</p>
        </div>
    </div>
    <button onclick=removeSection(this.id) id="${newId}">Remove section</button>`
    newSection.classList.add(`{newId}`);
}

// remove a section
function removeSection(id) {
    const section = document.getElementById(this.id);
    section.remove();
}